// modules/logger.js
// Custom logger module - reusable logging utility
// Demonstrates module.exports with multiple functions (an object)

function logInfo(message) {
  console.log(`[INFO]: ${message}`);
}

function logError(message) {
  console.log(`[ERROR]: ${message}`);
}

module.exports = { logInfo, logError };
