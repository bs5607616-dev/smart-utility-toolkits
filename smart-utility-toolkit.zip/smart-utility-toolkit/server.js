// server.js
// Basic HTTP server using Node's built-in http module (no Express)
// Run: node server.js
// Visit: http://localhost:3000/  -> Welcome to Node Server
// Visit: http://localhost:3000/about   -> About Page
// Visit: http://localhost:3000/contact -> Contact Page
// Any other route -> 404 Error Message

const http = require("http");

const PORT = 3000;

const server = http.createServer((req, res) => {
  console.log(`Request received for: ${req.url}`); // execution flow log

  res.setHeader("Content-Type", "text/plain");

  if (req.url === "/") {
    res.statusCode = 200;
    res.end("Welcome to Node Server");
  } else if (req.url === "/about") {
    res.statusCode = 200;
    res.end("About Page");
  } else if (req.url === "/contact") {
    res.statusCode = 200;
    res.end("Contact Page");
  } else {
    res.statusCode = 404;
    res.end("404 Error: Page Not Found");
  }
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});
